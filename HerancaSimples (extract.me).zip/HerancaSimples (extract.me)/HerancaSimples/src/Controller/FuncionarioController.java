package Controller;

import Model.*;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioController {
    public static void main(String[] args) {

        Funcionario devsenior1 = new DesenvolvedorSenior();
        Funcionario devsenior2 = new DesenvolvedorSenior("João Pedro", 3500.00);
        Funcionario gg1 = new GerenteGeral("Adryan", 6500.00);
        Funcionario gd1 = new GerenteDesenvolvimento("Gabriel", 4500.00);

        System.out.println(devsenior1);
        System.out.println(devsenior2);
        System.out.println(gg1);
        System.out.println(gd1);

        Funcionario devsenior3 = new DesenvolvedorSenior();
        System.out.println(devsenior3);

        devsenior1.setNome("João Victor");
        devsenior1.setSalario(3500.00);
        System.out.println(devsenior1);

        devsenior3.setNome("Erick");
        devsenior3.setSalario(3500.00);

        System.out.println(devsenior1.getNome() + " " + devsenior1.getBonus());
        System.out.println(devsenior2.getNome() + " " + devsenior2.getBonus());
        System.out.println(devsenior3.getNome() + " " + devsenior3.getBonus());
        System.out.println(gg1.getNome() + " " + gg1.getBonus());
        System.out.println(gd1.getNome() + " " + gd1.getBonus());

        // g.i) Não, pois o Funcionario está como abstrato, não posso criar instâncias para ele.
        // g.ii) Na, classe Desenvolvedor e Gerente, pois no controller não é um tipo,
        // e o Funcionario é abstract. Porque cada um tem um algoritmo diferente para ser calculado.

        List<Funcionario> funcionariosList = new ArrayList<>();
        funcionariosList.add(devsenior1);
        funcionariosList.add(devsenior2);
        funcionariosList.add(devsenior3);
        funcionariosList.add(gg1);
        funcionariosList.add(gd1);

        System.out.println("Coleção do tipo List de todos os funcionários: ");
        System.out.println(funcionariosList);

        //2b
        Funcionario devsenior4 = new DesenvolvedorSenior("Leandro", 3500.00);
        Funcionario devsenior5 = new DesenvolvedorSenior("Vagner", 3500.00);
        Funcionario devsenior6 = new DesenvolvedorSenior("Pablo", 3500.00);

        Funcionario devpleno1 = new DesenvolvedorPleno("André", 2500.00);
        Funcionario devpleno2 = new DesenvolvedorPleno("Guilherme", 2500.00);
        Funcionario devpleno3 = new DesenvolvedorPleno("Robson", 2500.00);
        Funcionario devpleno4 = new DesenvolvedorPleno("Otávio", 2500.00);
        Funcionario devpleno5 = new DesenvolvedorPleno("Lucas", 2500.00);
        Funcionario devpleno6 = new DesenvolvedorPleno("Lee", 2500.00);

        Funcionario devjunior1 = new DesenvolvedorJunior("Bella", 1800.00);
        Funcionario devjunior2 = new DesenvolvedorJunior("Stella", 1800.00);
        Funcionario devjunior3 = new DesenvolvedorJunior("Bill", 1800.00);
        Funcionario devjunior4 = new DesenvolvedorJunior("Louis", 1800.00);
        Funcionario devjunior5 = new DesenvolvedorJunior("Cadu", 1800.00);
        Funcionario devjunior6 = new DesenvolvedorJunior("Renato", 1800.00);

        funcionariosList.add(devsenior4);
        funcionariosList.add(devsenior5);
        funcionariosList.add(devsenior6);

        funcionariosList.add(devpleno1);
        funcionariosList.add(devpleno2);
        funcionariosList.add(devpleno3);
        funcionariosList.add(devpleno4);
        funcionariosList.add(devpleno5);
        funcionariosList.add(devpleno6);

        funcionariosList.add(devjunior1);
        funcionariosList.add(devjunior2);
        funcionariosList.add(devjunior3);
        funcionariosList.add(devjunior4);
        funcionariosList.add(devjunior5);
        funcionariosList.add(devjunior6);


        // fazer um loop somando todos os salarios + o bonus
        // antes criar uma variavel folhasalariobonus double,
        // for it (funcionarios f: funcionariosList) { folhasalariobonus += f.getSalario * f.getBonus }
        // sout folhasalariobonus
        //d) O MESMO sem bonus
        // a mesma logica do loop do bonus, + reajuste 5%

        //2c
        double total_folha_salarial_com_bonus = 0.0;
        for (Funcionario funcionario : funcionariosList) {
            total_folha_salarial_com_bonus += funcionario.getSalario() + funcionario.getBonus();
        }

        System.out.println("\nFolha salarial com bonus incluido: ");
        System.out.println(NumberFormat.getCurrencyInstance().format(total_folha_salarial_com_bonus));

        //2d

        double total_folha_salarial = 0.0;
        for (Funcionario funcionario : funcionariosList) {
            total_folha_salarial += funcionario.getSalario();
        }

        System.out.println("\nFolha salarial SEM o bonus incluido: ");
        System.out.println(NumberFormat.getCurrencyInstance().format(total_folha_salarial));

        //2e

        System.out.println("\n **** Salário bruto, bônus e salário de cada funcionário: ");

        for (Funcionario f : funcionariosList) {
            double salarioBruto = f.getSalario() + f.getBonus();
            System.out.println("\nFuncionário: " + f.getNome());
            System.out.println("Cargo: " + f.getClass().getSimpleName());
            System.out.println("Salário= " + NumberFormat.getCurrencyInstance().format(f.getSalario()));
            System.out.println("Bonus: " + NumberFormat.getCurrencyInstance().format(f.getBonus()));
            System.out.println("Salário bruto: " + NumberFormat.getCurrencyInstance().format(salarioBruto));
        }

        //2f
        total_folha_salarial_com_bonus = 0.0;
        for (Funcionario f : funcionariosList) {
            f.setSalario(f.getSalario() + (f.getSalario() * 0.05));
            total_folha_salarial_com_bonus += f.getSalario() + f.getBonus();
        }

        System.out.println("\nFolha salarial com bonus incluido COM REAJUSTE: ");
        System.out.println(NumberFormat.getCurrencyInstance().format(total_folha_salarial_com_bonus));
    }
}
