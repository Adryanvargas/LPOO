package Model;

public class DesenvolvedorSenior extends Desenvolvedor{

    public DesenvolvedorSenior(String nome, double salario) {
        super(nome, salario);
    }

    public DesenvolvedorSenior() {

    }

    public double getBonus() {
        return this.salario * 0.1;
    }

}
