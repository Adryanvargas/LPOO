package controller;

import model.*;
import org.w3c.dom.ls.LSOutput;

import java.util.ArrayList;
import java.util.List;

public class BankController {
    public static void main(String[] args) {

    Cliente c1 = new Cliente("Adryan");
    Cliente c2 = new Cliente("Erick");
    Cliente c3 = new Cliente("João Victor");

    ContaCorrente cc1 = new ContaCorrente(1000.0);
    ContaCorrente cc2 = new ContaCorrente(2000.0);
    ContaCorrente cc3 = new ContaCorrente(3000.0);

    ContaPoupanca cp1 = new ContaPoupanca(400.0);
    ContaPoupanca cp2 = new ContaPoupanca(500.0);
    ContaPoupanca cp3 = new ContaPoupanca(0.0);

        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);
        System.out.println(cc1);
        System.out.println(cc2);
        System.out.println(cc3);
        System.out.println(cp1);
        System.out.println(cp2);
        System.out.println(cp3);

        List<Conta> contas = new ArrayList<Conta>();
        contas.add(cc1);
        contas.add(cc2);
        contas.add(cc3);
        contas.add(cp1);
        contas.add(cp2);
        contas.add(cp3);

        List<Associado> associados = new ArrayList<>();
        associados.add(c1);
        associados.add(c2);
        associados.add(c3);
        associados.add(cc1);
        associados.add(cc2);
        associados.add(cc3);

        System.out.println(contas);
        System.out.println(associados);

        //1.e
        cp3.deposita(1000.0);
        cp3.atualiza(5.0);
        cp3.saca(1000.0);

        System.out.println(cp3);

        //1.f

        cc1.deposita(1000.0);
        cc1.atualiza(10.0);
        cc1.saca(1000.0);

        System.out.println(cc1);

        //1.g
        

    }
}
