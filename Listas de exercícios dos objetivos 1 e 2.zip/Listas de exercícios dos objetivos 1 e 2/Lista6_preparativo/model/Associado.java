package model;

public interface Associado {
    void getQdeCotas();

}
