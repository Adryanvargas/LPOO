package model;

public class Cliente implements Associado{
    private String nome;

    @Override
    public void getQdeCotas(){}

    public Cliente(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nome='" + nome + '\'' +
                '}';
    }
}
