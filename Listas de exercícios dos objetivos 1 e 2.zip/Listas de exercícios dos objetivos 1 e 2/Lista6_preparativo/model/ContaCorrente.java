package model;


public class ContaCorrente extends Conta implements Associado {

    @Override
    public void getQdeCotas() {}

    public ContaCorrente(double saldo) {
        super(saldo);
    }

    @Override
    public String toString() {
        return "ContaCorrente{" +
                "saldo=" + saldo +
                '}';
    }
}
