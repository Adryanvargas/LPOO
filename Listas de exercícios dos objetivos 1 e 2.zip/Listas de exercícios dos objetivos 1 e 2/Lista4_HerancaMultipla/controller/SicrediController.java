package controller;

import model.*;

import java.util.ArrayList;
import java.util.List;

public class SicrediController {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("João", "Gomes", "SICR3", 1000);
        Funcionario desenvolvedor = new Desenvolvedor("Erick", 5000.00);
        Funcionario gerente = new Gerente("Carlos", 10000.00, "SICR3", 1000);

        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(desenvolvedor);
        funcionarios.add(gerente);
        double acumuladorFolhaDePagamento = 0;
        for (Funcionario funcionario : funcionarios) {
            acumuladorFolhaDePagamento += funcionario.getSalario();
        }

        System.out.println("Total da folha de pagamento: " + acumuladorFolhaDePagamento);

        List<Investidor> investidores = new ArrayList<>();
        investidores.add((Investidor) gerente);
        investidores.add(cliente);

    }
}
