package model;

public interface Investidor {

    String getTicker();

    void setTicker(String ticker);

    int getQuantidade();

    void setQuantidade(int quantidade);


}
