package Model;

public class GerenteGeral extends Gerente{

    public GerenteGeral(String nome, double salario) {
        super(nome, salario);
    }

    public GerenteGeral() {
    }

    @Override
    public double getBonus() {
        return this.salario * 0.4;
    }
}
