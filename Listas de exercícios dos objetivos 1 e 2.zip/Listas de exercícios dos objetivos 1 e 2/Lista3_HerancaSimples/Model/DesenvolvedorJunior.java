package Model;

public class DesenvolvedorJunior extends Desenvolvedor{

    public DesenvolvedorJunior(String nome, double salario) {
        super(nome, salario);
    }

    public DesenvolvedorJunior() {
    }
}
