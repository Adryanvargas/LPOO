package Model;

public class GerenteDesenvolvimento extends Gerente{

    public GerenteDesenvolvimento(String nome, double salario) {
        super(nome, salario);
    }

    public GerenteDesenvolvimento() {
    }
}
