package Model;

public class DesenvolvedorPleno extends Desenvolvedor{

    public DesenvolvedorPleno(String nome, double salario) {
        super(nome, salario);
    }

    public DesenvolvedorPleno() {
    }
}
