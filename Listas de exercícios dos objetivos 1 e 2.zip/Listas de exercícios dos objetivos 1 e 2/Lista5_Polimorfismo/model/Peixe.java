package model;

public class Peixe extends Animal {
    private double z;

    public Peixe(double x, double y, double z) {
        super(x, y);
        this.z = z;
    }

    public void mover3D(double x, double y, double z){
        super.mover(x, y);
        this.z = z;
    }


    @Override
    public void desenhar() {
        System.out.println("Peixe desenhado");
    }

    @Override
    public String toString() {
        return "Peixe{" +
                "z=" + z +
                ", x=" + x +
                ", y=" + y +
                '}';
    }
}
