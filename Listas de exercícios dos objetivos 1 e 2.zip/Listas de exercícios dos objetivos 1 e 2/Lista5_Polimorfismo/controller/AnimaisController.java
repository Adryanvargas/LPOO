package controller;

import model.Animal;
import model.Cachorro;
import model.Passaro;
import model.Peixe;

import java.util.ArrayList;
import java.util.List;

public class AnimaisController {
    public static void main(String[] args) {
        Cachorro c1 = new Cachorro(1, 1);
        Cachorro c2 = new Cachorro(2, 2);
        Cachorro c3 = new Cachorro(3, 3);

        Passaro p1 = new Passaro(4, 4, 4);
        Passaro p2 = new Passaro(5, 5, 5);
        Passaro p3 = new Passaro(6, 6, 6);

        Peixe pe1 = new Peixe(7, 7, 7);
        Peixe pe2 = new Peixe(8, 8, 8);
        Peixe pe3 = new Peixe(9, 9, 9);

        List<Animal> animals = new ArrayList<>();
        animals.add(c1);
        animals.add(c2);
        animals.add(c3);
        animals.add(p1);
        animals.add(p2);
        animals.add(p3);
        animals.add(pe1);
        animals.add(pe2);
        animals.add(pe3);

        for (Animal a : animals) {
            a.desenhar();
            System.out.println(a);
        }

        for (Animal a : animals) {
            a.mover(2, 2);
            a.desenhar();
            System.out.println(a);
        }

        for (Animal a : animals ) {
            if (a instanceof Cachorro) {
                a.mover(8, 8);
                a.desenhar();
                System.out.println(a);
            } else if (a instanceof Passaro) {
                ((Passaro) a).mover3D(5, 5, 5);
                a.desenhar();
                System.out.println(a);
            } else if (a instanceof Peixe) {
                ((Peixe) a).mover3D(5, 5, 5);
                a.desenhar();
                System.out.println(a);
            }
        }

    }
}
