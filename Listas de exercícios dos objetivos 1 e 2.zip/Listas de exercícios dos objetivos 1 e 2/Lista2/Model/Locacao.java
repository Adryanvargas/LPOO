package Model;

import java.util.Date;

public class Locacao {
    private int id;
    private Date dataHoraLocacao;
    private Date dataHoraDevolucao;
    private int quilometragem;
    private double valor_caucao;
    private double valor_locaucao;
    private boolean devolucao;

    public Locacao() {
    }

    public Locacao(Date dataHoraLocacao, Date dataHoraDevolucao, int quilometragem, double valor_caucao, double valor_locaucao, boolean devolucao) {
        this.dataHoraLocacao = dataHoraLocacao;
        this.dataHoraDevolucao = dataHoraDevolucao;
        this.quilometragem = quilometragem;
        this.valor_caucao = valor_caucao;
        this.valor_locaucao = valor_locaucao;
        this.devolucao = devolucao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataHoraLocacao() {
        return dataHoraLocacao;
    }

    public void setDataHoraLocacao(Date dataHoraLocacao) {
        this.dataHoraLocacao = dataHoraLocacao;
    }

    public Date getDataHoraDevolucao() {
        return dataHoraDevolucao;
    }

    public void setDataHoraDevolucao(Date dataHoraDevolucao) {
        this.dataHoraDevolucao = dataHoraDevolucao;
    }

    public int getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(int quilometragem) {
        this.quilometragem = quilometragem;
    }

    public double getValor_caucao() {
        return valor_caucao;
    }

    public void setValor_caucao(double valor_caucao) {
        this.valor_caucao = valor_caucao;
    }

    public double getValor_locaucao() {
        return valor_locaucao;
    }

    public void setValor_locaucao(double valor_locaucao) {
        this.valor_locaucao = valor_locaucao;
    }

    public boolean isDevolucao() {
        return devolucao;
    }

    public void setDevolucao(boolean devolucao) {
        this.devolucao = devolucao;
    }

    @Override
    public String toString() {
        return "Locacao{" +
                "dataHoraLocacao=" + dataHoraLocacao +
                ", dataHoraDevolucao=" + dataHoraDevolucao +
                ", quilometragem=" + quilometragem +
                ", valor_caucao=" + valor_caucao +
                ", valor_locaucao=" + valor_locaucao +
                ", devolucao=" + devolucao +
                '}';
    }
}
