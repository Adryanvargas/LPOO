package Model;

public class Modelo {
    private int id;
    private int descricao;

    public Modelo() {
    }

    public Modelo(int descricao) {
        this.descricao = descricao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDescricao() {
        return descricao;
    }

    public void setDescricao(int descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Modelo{" +
                "descricao=" + descricao +
                '}';
    }
}
