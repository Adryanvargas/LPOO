package Controller;

import Model.Automovel;

import java.sql.SQLOutput;
import java.util.*;

public class AutomovelController {
    public static void main(String[] args) {
            //1c-i
            Automovel automovel1 = new Automovel();
            Automovel automovel2 = new Automovel();

            //1c-ii
            Automovel automovel3 = new Automovel("1", "UUU-1111", "preto", 4, "Flex", 2000, "qwerty-1", 50.00);
            Automovel automovel4 = new Automovel("2", "AAA-2222", "azul", 4, "Hybrid", 3000, "qwerty-2", 60.00);

            //1c-iii
            Automovel automovel5 = new Automovel("5", "Tesla preto 4p");
            Automovel automovel6 = new Automovel("6", "Tesla branco 4p");

            //1c-iv
            System.out.println("Automovel 1: " + automovel1);
            System.out.println("Automovel 2: " + automovel2);
            System.out.println("Automovel 3: " + automovel3);
            System.out.println("Automovel 4: " + automovel4);
            System.out.println("Automovel 5: " + automovel5);
            System.out.println("Automovel 6: " + automovel6);

            //1c-v
        automovel1.setRenavan("1");
        automovel1.setPlaca("AAA-1111");
        automovel1.setCor("Preto");
        automovel1.setNum_rodas(4);
        automovel1.setCombustivel("flex");
        automovel1.setQuilometragem(1000);
        automovel1.setChassi("qwerty-111");
        automovel1.setValor_locacao(50.00);
        automovel2.setRenavan("2");
        automovel2.setPlaca("BBB-2222");
        automovel2.setCor("Prata");
        automovel2.setNum_rodas(4);
        automovel2.setCombustivel("hybrid");
        automovel2.setQuilometragem(2000);
        automovel2.setChassi("qwerty-222");
        automovel2.setValor_locacao(60.00);

        automovel3.setRenavan("3");
        automovel3.setPlaca("CCC-3333");
        automovel3.setCor("Branco");
        automovel3.setNum_rodas(4);
        automovel3.setCombustivel("flex");
        automovel3.setQuilometragem(3000);
        automovel3.setChassi("qwerty-333");
        automovel3.setValor_locacao(70.00);
        automovel4.setRenavan("4");
        automovel4.setPlaca("DDD-4444");
        automovel4.setCor("Prata");
        automovel4.setNum_rodas(4);
        automovel4.setCombustivel("elétrico");
        automovel4.setQuilometragem(4000);
        automovel4.setChassi("qwerty-444");
        automovel4.setValor_locacao(80.00);

        automovel5.setRenavan("5");
        automovel5.setPlaca("EEE-5555");
        automovel5.setCor("Preto");
        automovel5.setNum_rodas(4);
        automovel5.setCombustivel("flex");
        automovel5.setQuilometragem(5000);
        automovel5.setChassi("qwerty-555");
        automovel5.setValor_locacao(90.00);
        automovel6.setRenavan("6");
        automovel6.setPlaca("DDD-6666");
        automovel6.setCor("Prata");
        automovel6.setNum_rodas(4);
        automovel6.setCombustivel("elétrico");
        automovel6.setQuilometragem(6000);
        automovel6.setChassi("qwerty-666");
        automovel6.setValor_locacao(100.00);

        //1c-vi
        System.out.println(automovel1.getRenavan());
        System.out.println(automovel1.getPlaca());
        System.out.println(automovel1.getCor());
        System.out.println(automovel1.getNum_rodas());
        System.out.println(automovel1.getCombustivel());
        System.out.println(automovel1.getQuilometragem());
        System.out.println(automovel1.getChassi());
        System.out.println(automovel2.getValor_locacao());
        System.out.println(automovel2.getRenavan());
        System.out.println(automovel2.getPlaca());
        System.out.println(automovel2.getCor());
        System.out.println(automovel2.getNum_rodas());
        System.out.println(automovel2.getCombustivel());
        System.out.println(automovel2.getQuilometragem());
        System.out.println(automovel2.getChassi());
        System.out.println(automovel2.getValor_locacao());



        System.out.println(automovel3.getRenavan());
        System.out.println(automovel3.getPlaca());
        System.out.println(automovel3.getCor());
        System.out.println(automovel3.getNum_rodas());
        System.out.println(automovel3.getCombustivel());
        System.out.println(automovel3.getQuilometragem());
        System.out.println(automovel3.getChassi());
        System.out.println(automovel3.getValor_locacao());
        System.out.println(automovel4.getRenavan());
        System.out.println(automovel4.getPlaca());
        System.out.println(automovel4.getCor());
        System.out.println(automovel4.getNum_rodas());
        System.out.println(automovel4.getCombustivel());
        System.out.println(automovel4.getQuilometragem());
        System.out.println(automovel4.getChassi());
        System.out.println(automovel4.getValor_locacao());

        System.out.println(automovel5.getRenavan());
        System.out.println(automovel5.getPlaca());
        System.out.println(automovel5.getCor());
        System.out.println(automovel5.getNum_rodas());
        System.out.println(automovel5.getCombustivel());
        System.out.println(automovel5.getQuilometragem());
        System.out.println(automovel5.getChassi());
        System.out.println(automovel5.getValor_locacao());
        System.out.println(automovel6.getRenavan());
        System.out.println(automovel6.getPlaca());
        System.out.println(automovel6.getCor());
        System.out.println(automovel6.getNum_rodas());
        System.out.println(automovel6.getCombustivel());
        System.out.println(automovel6.getQuilometragem());
        System.out.println(automovel6.getChassi());
        System.out.println(automovel6.getValor_locacao());

        //2a
        List<Automovel> automovelList = new ArrayList<>();
        //2d
        automovelList.add(automovel1);
        automovelList.add(automovel2);
        automovelList.add(automovel3);
        automovelList.add(automovel4);
        automovelList.add(automovel5);
        automovelList.add(automovel6);
        //2e
        System.out.println("\nColeção de automoveis: \n" + automovelList);

        //2c
        automovel1.setId(1);
        automovel2.setId(2);
        automovel3.setId(3);
        automovel4.setId(4);
        automovel5.setId(5);
        automovel6.setId(6);

        //2f
        System.out.println();
        automovelList.sort(Comparator.comparing(Automovel::getRenavan).reversed());
        System.out.println("\nColeção em ordem decrescente, chave Renavam: \n");
        System.out.println(automovelList);

        //2g
        for(Automovel automovel : automovelList){
                if(automovel.getRenavan().equals("3")){
                    System.out.println("\nResultado de pesquisa a partir do Renavan = 3");
                    System.out.println(automovel);
                }
        }

        //2h
        System.out.println();
        System.out.println("\nLocalizando o automovel pela chave Renavan = 3, usando o método binarySearch");
        automovelList.sort(Comparator.comparing(Automovel::getRenavan));
        System.out.println(automovelList.get(
                Collections.binarySearch(
                        automovelList,
                        automovel3,
                        Comparator.comparing(Automovel::getRenavan)
                )
        ));

        //2a ao h, para Map
        Map<String, Automovel> automovelMap = new HashMap<>();
        automovelMap.put(automovel1.getRenavan(), automovel1);
        automovelMap.put(automovel2.getRenavan(), automovel2);
        automovelMap.put(automovel3.getRenavan(), automovel3);
        automovelMap.put(automovel4.getRenavan(), automovel4);
        automovelMap.put(automovel5.getRenavan(), automovel5);
        automovelMap.put(automovel6.getRenavan(), automovel6);
        System.out.println("\nColeção do tipo Map:\n" + automovelMap);

        System.out.println();
        System.out.println("\nLocalizando o Automovel pel chave Renavan = 3, na coleção tipo Map;\n");
        System.out.println(automovelMap.get("3"));


    }
}
