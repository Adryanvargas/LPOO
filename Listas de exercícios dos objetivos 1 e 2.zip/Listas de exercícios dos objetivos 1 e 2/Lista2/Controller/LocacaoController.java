package Controller;

public class LocacaoController {
    public static void main(String[] args) {

    }
}
