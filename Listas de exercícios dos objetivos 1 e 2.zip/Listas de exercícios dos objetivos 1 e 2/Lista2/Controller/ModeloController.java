package Controller;

public class ModeloController {
    public static void main(String[] args) {

    }
}
