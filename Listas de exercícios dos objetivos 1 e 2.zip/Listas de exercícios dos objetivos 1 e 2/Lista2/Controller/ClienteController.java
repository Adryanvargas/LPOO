package Controller;

import Model.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteController {
    public static void main(String[] args) {
        Cliente cliente1 = new Cliente();
        Cliente cliente2 = new Cliente();

        Cliente cliente3 = new Cliente("01234567890", "Bella", "Borges", "Rua 5", "987654321", "bella@gmail.com");
        Cliente cliente4 = new Cliente("09876543210", "Stella", "Borges", "Rua 5", "912345678", "stella@gmail.com");

        Cliente cliente5 = new Cliente("Pablo Emilio", "Borges");
        Cliente cliente6 = new Cliente("Louis", "Borges");

        System.out.println(cliente1);
        System.out.println(cliente2);
        System.out.println(cliente3);
        System.out.println(cliente4);
        System.out.println(cliente5);
        System.out.println(cliente6);


        List<Cliente> clienteList = new ArrayList<>();

        clienteList.add(cliente1);
        clienteList.add(cliente2);
        clienteList.add(cliente3);
        clienteList.add(cliente4);
        clienteList.add(cliente5);
        clienteList.add(cliente6);

        cliente1.setId(1);
        cliente2.setId(2);
        cliente3.setId(3);
        cliente4.setId(4);
        cliente5.setId(5);
        cliente6.setId(6);

        System.out.println("\nColeção de Clientes tipo List:\n" + clienteList);

        //falta 1v, 1vi, 2f, 2g e 2h


    }
}
