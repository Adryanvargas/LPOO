package model;

public class Empresa {
    private String cnpj;
    private String razaoSocial;
    private String nomeFantasia;
}
