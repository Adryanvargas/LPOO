package model;

import java.util.Date;

public class Funcionario {
    private long id;
    private String cpf;
    private String nome;
    private String sobrenome;
    private Date dataDeNascimento;
}
