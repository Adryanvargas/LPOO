package model;

public class Veiculo {
    private String placa;
    private String renavam;
    private String fabricante;
    private String modelo;
    private int anoDeFabricacao;
}
