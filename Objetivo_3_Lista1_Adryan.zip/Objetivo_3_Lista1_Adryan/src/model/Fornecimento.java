package model;

import java.math.BigDecimal;
import java.util.Date;

public class Fornecimento {
    private Date data;
    private int quantidade;
    private BigDecimal total;
}
