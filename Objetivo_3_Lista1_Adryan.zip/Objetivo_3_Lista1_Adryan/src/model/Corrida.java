package model;

import java.math.BigDecimal;
import java.util.Date;

public class Corrida {
    private BigDecimal valor;
    private Date dataInicio;
    private Date dataFim;
}
