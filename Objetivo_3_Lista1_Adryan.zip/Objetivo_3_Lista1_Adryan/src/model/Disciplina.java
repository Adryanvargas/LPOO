package model;

public class Disciplina {
    private long codigo;
    private String nome;
}
