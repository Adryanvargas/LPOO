package model;

public class Motorista {
    private String nome;
    private String email;
    private String telefone;
}
