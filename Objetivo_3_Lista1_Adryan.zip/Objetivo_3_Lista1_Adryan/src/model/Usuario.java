package model;

public class Usuario {
    private String nome;
    private String email;
    private String telefone;
}
