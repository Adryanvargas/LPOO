package model;

public enum FormaDePagamento {
    CartaoDebito,
    CartaoCredito,
    Pix,
}
