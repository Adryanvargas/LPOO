package model;

public enum Situacao {
    Agendada,
    EmAndamento,
    Faturada,
}
