package model;

import java.math.BigDecimal;

public class Produto {
    private String sku;
    private String nome;
    private String descricao;
    private int quantidade;
    private BigDecimal precoDeCusto;
    private BigDecimal precoDeVenda;
}
