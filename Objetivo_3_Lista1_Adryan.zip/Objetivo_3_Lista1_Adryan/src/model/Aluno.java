package model;

public class Aluno {
    private long matricula;
    private String nome;
    private String sobrenome;
}
